# Taxi Hotspot Batch + Streaming

Đây là pipeline batch + streaming cho dự báo điểm nóng taxi: batch tạo dữ liệu sạch và model artifact một lần, còn streaming chỉ load artifact để chấm điểm hotspot và ghi MongoDB. Phạm vi nghiệp vụ tập trung vào phát hiện điểm nóng và điều phối taxi; không xử lý giá cước/doanh thu.

## Chạy toàn bộ

```bash
docker compose up --build
```

Sau khi stack khởi động:

- Spark UI: http://localhost:8080
- HDFS NameNode UI: http://localhost:9870
- Dashboard/API: http://localhost:8088
- Dashboard health: http://localhost:8088/health

Nếu cổng Spark UI `8080` đã được ứng dụng khác sử dụng, chọn cổng host khác trước khi chạy stack (ví dụ PowerShell):

```powershell
$env:SPARK_UI_PORT="18080"
docker compose up --build
```

Khi đó Spark UI ở `http://localhost:18080`; cổng bên trong container vẫn giữ nguyên.

Các stage one-shot sẽ hiện các log `[PASS]`: HDFS, MapReduce, ETL/Parquet, model và Kafka topic. `streaming-predictor`, `kafka-producer` và `dashboard` tiếp tục chạy; producer lặp lại dataset để mô phỏng luồng realtime cho đến khi bạn dừng bằng `docker compose stop kafka-producer`.

## Artifact và chạy lại

- Model: `models/hotspot_model/`
- Chỉ số đánh giá model holdout (RMSE/MAE): `data/results/model_metrics.json`
- Checkpoint realtime: `checkpoints/taxi-hotspot-realtime-v4/`
- Dữ liệu local: `data/raw`, `data/curated`, `data/results`
- HDFS: `/taxi/raw` và `/taxi/curated/trips`
- MongoDB collection: `taxi.hotspot_predictions`
- Kafka topic realtime: `taxi_trips_realtime_v2`

Những lần `docker compose up` sau sẽ bỏ qua train nếu model artifact đã tồn tại. Chủ động train lại:

```bash
docker compose run --rm -e FORCE_TRAIN=true model-trainer
```

Stage train lấy các chuyến taxi từ nguồn ETL trong HDFS, nhóm theo ngày, zone, giờ và thứ trong tuần. Nhãn mỗi ngày là hotspot score = số chuyến của zone trong ngày/giờ ÷ số chuyến lớn nhất trong cùng ngày/giờ × 100. GBTRegressor học score tương đối từ zone, giờ và thứ; zone được one-hot encode và không dùng KMeans. Đánh giá dùng temporal holdout: 80% ngày sớm nhất để train, 20% ngày mới nhất để test; hai giai đoạn không trộn lẫn. Cần ít nhất hai ngày dữ liệu. RMSE/MAE trên giai đoạn test, ngày đầu/cuối và số ngày của từng tập được lưu tại `data/results/model_metrics.json`; dashboard đọc metric artifact sau khi train. Kết quả đo này kiểm tra score tương đối trên các ngày chưa thấy, không phải dự báo số chuyến thực tế.

Batch cũng bỏ qua MapReduce/ETL nếu artifact đã có. Khi thay bộ Parquet nguồn, chạy lại có chủ đích:

```bash
docker compose run --rm -e FORCE_BATCH=true mapreduce-job
docker compose run --rm -e FORCE_ETL=true spark-etl
docker compose run --rm -e FORCE_TRAIN=true model-trainer
```

Nếu muốn reset toàn bộ dữ liệu demo, dừng stack rồi xóa các thư mục `models/`, `checkpoints/`, `data/results/` và dùng `docker compose down -v` để xóa named volumes HDFS/Kafka/MongoDB. Đây là thao tác destructive.

## Lưu ý phạm vi và nguồn dữ liệu

- **Batch và model:** mặc định đọc 7 file NYC TLC Yellow Taxi Parquet đã có trong workspace tại `Nyc taxi trip record/Nyc taxi trip record/` (mẫu `yellow_tripdata_*.parquet`). Đây là dữ liệu chuyến taxi Yellow Taxi do NYC Taxi & Limousine Commission công bố; các cột chính pipeline dùng là `tpep_pickup_datetime`, `PULocationID`, `DOLocationID`. MapReduce đếm chuyến theo zone/giờ, Spark ETL tạo bảng curated, và model học điểm hotspot tương đối từ các chuyến đó.
- **Lấy bản gốc:** tải Yellow Taxi Trip Records từ [NYC TLC Trip Record Data](https://www.nyc.gov/site/tlc/about/tlc-trip-record-data.page) hoặc [NYC TLC trên AWS Open Data](https://registry.opendata.aws/nyc-tlc-trip-records/), rồi đặt các Parquet `yellow_tripdata_*.parquet` vào thư mục trên. Project không tự tải toàn bộ dataset khi khởi động. Muốn dùng bộ khác, đặt file ở đó và chạy lại batch, ETL, rồi train bằng các lệnh `FORCE_BATCH`, `FORCE_ETL`, `FORCE_TRAIN` bên trên.
- **Fallback:** nếu không có Parquet TLC trong thư mục, MapReduce tạo `data/raw/taxi_trips.csv` với dữ liệu deterministic tổng hợp (mặc định 10.000 dòng). Dữ liệu fallback mô phỏng schema TLC, không phải chuyến đi thật. Có thể đặt CSV của bạn tại `data/raw/taxi_trips.csv`; generator giữ nguyên file đã tồn tại. Nguồn CSV fallback này cũng được dùng cho realtime replay.
- **Realtime replay:** producer phát tối đa `SIMULATION_SOURCE_ROWS` dòng từ cùng bộ Parquet TLC; nếu không có thì đọc CSV fallback trong `data/raw/taxi_trips.csv`. Timestamp lịch sử được thay bằng simulation clock hiện tại (UTC+7), vì vậy đây là phát lại tăng tốc, không phải live feed.
- **Vị trí và trạng thái xe:** 40 xe, tốc độ và trạng thái do simulator tạo ra; chúng không đến từ GPS hoặc dữ liệu định vị NYC TLC. Đường đi được lấy từ OSRM trên dữ liệu đường OpenStreetMap, xe di chuyển dọc hình học tuyến lái xe. Dịch vụ định tuyến cần kết nối Internet; nếu không lấy được tuyến, xe đứng yên và thử lại, không tự đi đường thẳng. Có thể đổi endpoint bằng `ROUTING_BASE_URL`, thời gian thử lại bằng `ROUTE_RETRY_SECONDS` và giới hạn nhịp gọi bằng `ROUTE_REQUEST_INTERVAL_SECONDS`.

Tham khảo cấu trúc cột tại [Yellow Taxi Data Dictionary](https://www.nyc.gov/assets/tlc/downloads/pdf/data_dictionary_trip_records_yellow.pdf) và zone tại [Taxi Zone Lookup CSV](https://d37ci6vzury5cl.cloudfront.net/misc/taxi_zone_lookup.csv).

## Ảnh chụp và evidence

- Ảnh dashboard runtime ngày 03/10/2026: [`output/playwright/runtime-dashboard-2026-10-03.png`](output/playwright/runtime-dashboard-2026-10-03.png), thể hiện số liệu dashboard và RMSE/MAE từ temporal holdout.
- Ảnh bản đồ vùng hotspot cùng lần chạy: [`output/playwright/map-hotspots.png`](output/playwright/map-hotspots.png).
- Bản ghi kiểm tra tổng quát: [`evidence/verification_summary.json`](evidence/verification_summary.json); số đếm API, forecast, fleet, MongoDB, HDFS và Kafka: [`evidence/runtime_metrics.json`](evidence/runtime_metrics.json).
- Schema, row count, pickup-date range, zone count và null profile của raw/curated Parquet: [`evidence/data_profile.json`](evidence/data_profile.json). HDFS checksums cho 7 raw files: [`evidence/hdfs_raw_checksums.txt`](evidence/hdfs_raw_checksums.txt).
- Kết quả train: [`evidence/model_metrics.json`](evidence/model_metrics.json) và [`evidence/forced_training.log`](evidence/forced_training.log). Model GBTRegressor được đánh giá bằng temporal holdout.
- SHA-256 manifest cho screenshot, metrics, training log, profile và runtime snapshots: [`evidence/artifact_checksums.json`](evidence/artifact_checksums.json).
- API snapshots, fleet trước/sau, HDFS listings, Kafka topics, Mongo count, model metadata và service logs được lưu trong [`evidence/`](evidence/).
- Dữ liệu hotspot trên map: [`output/playwright/dispatch-hotspots.json`](output/playwright/dispatch-hotspots.json), gồm điểm trung bình và số bản ghi suy luận theo zone.
- Data profile hiện ghi nhận 26.116.976 dòng raw và curated; 31 dòng có pickup year trước 2025 (2001: 1, 2008: 4, 2009: 5, 2024: 21). Những dòng này vẫn được giữ trong dữ liệu đã train; temporal train bắt đầu từ 2001-01-01.
- Để thu lại evidence từ stack đang chạy, dùng `scripts/collect_evidence.ps1`; script tạo API snapshots, Spark schema/row profile, HDFS checksums/listings, Kafka topics, MongoDB counts, model metrics/artifact metadata và SHA-256 manifest.

`analytics.py` và `features.py` là các entrypoint mở rộng cho phân tích/feature engineering; pipeline mặc định đã thực hiện feature engineering trong `train_model.py`.

## Realtime simulation theo schema NYC TLC

Batch ưu tiên dùng các file NYC TLC Parquet đặt tại `Nyc taxi trip record/Nyc taxi trip record`: MapReduce quét `PULocationID` theo giờ, HDFS lưu Parquet gốc, và Spark ETL đọc trực tiếp Parquet để tạo dữ liệu curated. Nếu thư mục không có, pipeline tự fallback về CSV mô phỏng deterministic. Producer lấy tối đa `SIMULATION_SOURCE_ROWS` bản ghi từ cùng nguồn Parquet để phát sự kiện realtime; ngoài hotspot event, producer còn phát snapshot 40 xe vào topic `taxi_vehicles`, `fleet-tracker` đọc topic này và lưu trạng thái hiện tại vào collection `taxi.vehicle_status` để dashboard hiển thị bản đồ và danh sách xe.

Dashboard tiếng Việt tại `http://localhost:8088/` có điều hướng, filter pickup zone, bản đồ OpenStreetMap, ranh giới zone mô phỏng, marker xe đang chạy, điểm nóng theo thang 0–100, ranking khu vực, điều phối taxi và forecast điểm nóng 3 giờ kế tiếp. Marker được nội suy giữa các snapshot Kafka để chuyển động liền mạch; producer chạy lặp liên tục và dừng bằng `docker compose stop kafka-producer`.

**Vì sao một zone nóng:** model đếm chuyến đón theo zone, giờ và thứ trong tuần từ dữ liệu batch. Score = (số chuyến của zone ÷ số chuyến cao nhất trong cùng giờ và thứ) × 100; zone dẫn đầu đạt 100. GBTRegressor học dự đoán score này từ zone, giờ và thứ, không dùng KMeans. Streaming áp dụng model lên sự kiện replay; map hiển thị điểm trung bình và số bản ghi dự báo đã lưu theo zone. Điểm hotspot là mức tương đối, không phải số chuyến thực tế hay nhu cầu live.

Producer dùng simulation clock theo ngày/giờ hiện tại UTC+7, phát event đầu tiên tại thời điểm khởi động và tiến 1 giây mô phỏng cho mỗi event (có thể điều chỉnh bằng `SIMULATION_EVENT_TIME_STEP_SECONDS`). Snapshot đội xe phát mỗi 10 event; xe có tọa độ đích, hướng, tốc độ, tiến độ và ETA. Tuyến gọi OSRM Route API với hồ sơ `driving`; tọa độ điểm đi/đến được OSRM snap vào mạng đường gần nhất. Đây là mô phỏng realtime tăng tốc, không phải GPS xe thật. Mặc định producer giới hạn yêu cầu định tuyến cách nhau 1,1 giây; khi mới khởi động, các xe sẽ nhận tuyến dần theo nhịp này.

Các ô ranh giới trên map là 260 zone hình lưới do simulator định nghĩa trong phạm vi vận hành NYC; zone có điểm nóng sẽ được tô màu và hover để xem hotspot score.

Điều chỉnh tốc độ hoặc số event:

```bash
$env:PRODUCER_DELAY_SECONDS="0.10"
$env:SIMULATION_MAX_EVENTS="1000"
docker compose up --build
```

Để lấy một sample chính thức và bảng zone lookup:

```bash
docker compose run --rm --no-deps --entrypoint python3 kafka-topic-init /workspace/scripts/fetch_tlc_sample.py
```

Lệnh trên lưu sample vào `data/reference/`. Simulator vẫn là dữ liệu deterministic để demo ổn định, nhưng dùng đúng tên cột và taxi-zone vocabulary của TLC; nếu file zone lookup tồn tại, các zone được lấy từ file đó.

Nguồn dữ liệu được dùng làm chuẩn:

- NYC TLC Trip Record Data: https://www.nyc.gov/site/tlc/about/tlc-trip-record-data.page
- Yellow Taxi Data Dictionary: https://www.nyc.gov/assets/tlc/downloads/pdf/data_dictionary_trip_records_yellow.pdf
- Taxi Zone Lookup CSV: https://d37ci6vzurychx.cloudfront.net/misc/taxi_zone_lookup.csv
- NYC TLC dataset trên AWS Open Data: https://registry.opendata.aws/nyc-tlc-trip-records-pds/

`spark/clean.py` hỗ trợ schema TLC (`tpep_pickup_datetime`, `PULocationID`, `DOLocationID`) và schema CSV chuẩn hóa cũ. Bộ zone lookup chính thức được tải vào `data/reference/` bằng lệnh sample ở trên; simulator có thể dùng danh sách zone đó cho dữ liệu tổng hợp.
