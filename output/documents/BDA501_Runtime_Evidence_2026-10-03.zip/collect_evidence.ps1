$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $PSScriptRoot
$evidence = Join-Path $root "evidence"
New-Item -ItemType Directory -Force -Path $evidence | Out-Null
$stamp = Get-Date -Format "yyyyMMdd-HHmmss"

function Save-Json($name, $value) {
    $value | ConvertTo-Json -Depth 12 | Set-Content -Encoding utf8 (Join-Path $evidence $name)
}

docker compose ps -a | Set-Content -Encoding utf8 (Join-Path $evidence "compose_ps.txt")
docker compose logs --no-color --tail=300 | Set-Content -Encoding utf8 (Join-Path $evidence "compose_logs.txt")
foreach ($service in @("mapreduce-job", "spark-etl", "model-trainer", "streaming-predictor", "kafka-producer", "fleet-tracker", "dashboard")) {
    docker compose logs --no-color $service | Set-Content -Encoding utf8 (Join-Path $evidence ("service_{0}.log" -f $service.Replace("-", "_")))
}
docker compose config --quiet
"PASS docker compose config" | Set-Content -Encoding utf8 (Join-Path $evidence "compose_config.txt")

docker exec taxi-demand-spark-master-1 /opt/spark/bin/spark-submit --master local[2] /workspace/scripts/profile_data_evidence.py | Set-Content -Encoding utf8 (Join-Path $evidence "data_profile.json")
if ($LASTEXITCODE -ne 0) { throw "Spark data profile failed with exit code $LASTEXITCODE" }

$health = Invoke-RestMethod "http://localhost:8088/health"
Save-Json "dashboard_health.json" $health
$dashboard = Invoke-RestMethod "http://localhost:8088/api/dashboard"
Save-Json "dashboard_snapshot.json" $dashboard
$dispatch = Invoke-RestMethod "http://localhost:8088/api/dispatch"
Save-Json "dispatch_hotspots.json" $dispatch
$hotspots = Invoke-RestMethod "http://localhost:8088/api/upcoming-hotspots?hours=3"
Save-Json "upcoming_hotspots.json" $hotspots

$vehiclesBefore = Invoke-RestMethod "http://localhost:8088/api/vehicles"
Save-Json "vehicles_before.json" $vehiclesBefore
Start-Sleep -Seconds 6
$vehiclesAfter = Invoke-RestMethod "http://localhost:8088/api/vehicles"
Save-Json "vehicles_after.json" $vehiclesAfter

$before = @($vehiclesBefore.vehicles) | Where-Object vehicle_id -eq "NYC-TAXI-001" | Select-Object -First 1
$after = @($vehiclesAfter.vehicles) | Where-Object vehicle_id -eq "NYC-TAXI-001" | Select-Object -First 1
$movement = [ordered]@{
    vehicle_id = "NYC-TAXI-001"
    before = $before
    after = $after
    changed = (($before.latitude -ne $after.latitude) -or ($before.longitude -ne $after.longitude) -or ($before.simulation_cycle -ne $after.simulation_cycle))
}
Save-Json "vehicle_movement.json" $movement

$modelPath = Join-Path $root "models\hotspot_model\metadata\part-00000"
$modelDir = Join-Path $root "models\hotspot_model"
$modelEvidence = [ordered]@{
    path = $modelPath
    exists = Test-Path -LiteralPath $modelPath
    size_bytes = if (Test-Path -LiteralPath $modelPath) { (Get-Item -LiteralPath $modelPath).Length } else { 0 }
    last_write_time = if (Test-Path -LiteralPath $modelPath) { (Get-Item -LiteralPath $modelPath).LastWriteTime.ToString("o") } else { $null }
    metadata_sha256 = if (Test-Path -LiteralPath $modelPath) { (Get-FileHash -LiteralPath $modelPath -Algorithm SHA256).Hash } else { $null }
    artifact_file_count = if (Test-Path -LiteralPath $modelDir) { @(Get-ChildItem -LiteralPath $modelDir -File -Recurse).Count } else { 0 }
    artifact_total_bytes = if (Test-Path -LiteralPath $modelDir) { (Get-ChildItem -LiteralPath $modelDir -File -Recurse | Measure-Object -Property Length -Sum).Sum } else { 0 }
}
Save-Json "model_artifact.json" $modelEvidence

$metricsPath = Join-Path $root "data\results\model_metrics.json"
if (Test-Path -LiteralPath $metricsPath) {
    Save-Json "model_metrics.json" (Get-Content -Raw -LiteralPath $metricsPath | ConvertFrom-Json)
}

docker exec taxi-demand-namenode-1 hdfs dfs -ls -h /taxi/raw | Set-Content -Encoding utf8 (Join-Path $evidence "hdfs_raw.txt")
docker exec taxi-demand-namenode-1 hdfs dfs -ls -h /taxi/raw/parquet | Set-Content -Encoding utf8 (Join-Path $evidence "hdfs_raw_parquet_files.txt")
docker exec taxi-demand-namenode-1 hdfs dfs -checksum /taxi/raw/parquet/yellow_tripdata_*.parquet | Set-Content -Encoding utf8 (Join-Path $evidence "hdfs_raw_checksums.txt")
docker exec taxi-demand-namenode-1 hdfs dfs -ls -h /taxi/curated/trips | Set-Content -Encoding utf8 (Join-Path $evidence "hdfs_curated_parquet.txt")
docker exec taxi-demand-kafka-1 /opt/kafka/bin/kafka-topics.sh --bootstrap-server localhost:9092 --list | Set-Content -Encoding utf8 (Join-Path $evidence "kafka_topics.txt")

$mongoCount = docker exec taxi-demand-mongodb-1 mongosh --quiet --eval "db.getSiblingDB('taxi').hotspot_predictions.countDocuments({})"
[ordered]@{ collection = "taxi.hotspot_predictions"; count = [int]$mongoCount.Trim() } | ConvertTo-Json | Set-Content -Encoding utf8 (Join-Path $evidence "mongo_hotspot_count.json")

$pass = [ordered]@{
    collected_at = (Get-Date).ToString("o")
    dashboard_health = ($health.status -eq "ok")
    hotspot_records = ([int]$dashboard.summary.count -gt 0)
    hotspot_explanations = (@($dispatch.hotspots).Count -gt 0 -and @($dispatch.hotspots | Where-Object { [int]$_.sample_count -le 0 }).Count -eq 0)
    upcoming_hotspots = (@($hotspots.forecasts).Count -eq 3)
    fleet_records = ($vehiclesAfter.count -ge 40)
    fleet_moved = [bool]$movement.changed
    model_artifact = [bool]$modelEvidence.exists
    mongo_records = ([int]$mongoCount.Trim() -gt 0)
    hdfs_raw_parquet = ((Get-Content (Join-Path $evidence "hdfs_raw_parquet_files.txt") | Where-Object { $_ -match "yellow_tripdata_.*\.parquet" }).Count -eq 7)
}
Save-Json "verification_summary.json" $pass
$runtime = [ordered]@{
    collected_at = $pass.collected_at
    prediction_records = [int]$dashboard.summary.count
    zones_with_data = [int]$dashboard.summary.zones
    latest_prediction_time = $dashboard.summary.latest
    mongo_prediction_records = [int]$mongoCount.Trim()
    fleet_vehicle_count = [int]$vehiclesAfter.count
    fleet_movement_verified = [bool]$movement.changed
    upcoming_forecast_horizons = @($hotspots.forecasts | ForEach-Object { $_.label })
    hotspot_zone_ranking = @($dispatch.hotspots | Select-Object -First 5 | ForEach-Object { [ordered]@{ zone = $_.zone; score = $_.hotspot_score; samples = $_.sample_count } })
    model_evaluation = if (Test-Path -LiteralPath $metricsPath) { Get-Content -Raw -LiteralPath $metricsPath | ConvertFrom-Json } else { $null }
    hdfs_raw_parquet_file_count = (Get-Content (Join-Path $evidence "hdfs_raw_parquet_files.txt") | Where-Object { $_ -match "yellow_tripdata_.*\.parquet" }).Count
    hdfs_raw_trip_rows = (Get-Content -Raw -LiteralPath (Join-Path $evidence "data_profile.json") | ConvertFrom-Json).raw.row_count
    hdfs_curated_trip_rows = (Get-Content -Raw -LiteralPath (Join-Path $evidence "data_profile.json") | ConvertFrom-Json).curated.row_count
    source_pickup_date_min = (Get-Content -Raw -LiteralPath (Join-Path $evidence "data_profile.json") | ConvertFrom-Json).raw.pickup_datetime_min
    source_pickup_date_max = (Get-Content -Raw -LiteralPath (Join-Path $evidence "data_profile.json") | ConvertFrom-Json).raw.pickup_datetime_max
    curated_distinct_pickup_zones = (Get-Content -Raw -LiteralPath (Join-Path $evidence "data_profile.json") | ConvertFrom-Json).curated.distinct_pickup_zones
    kafka_topics = @(Get-Content (Join-Path $evidence "kafka_topics.txt") | Where-Object { $_ -and $_ -ne "__consumer_offsets" })
}
Save-Json "runtime_metrics.json" $runtime
$pass.GetEnumerator() | ForEach-Object { "{0}={1}" -f $_.Key, $_.Value } | Set-Content -Encoding utf8 (Join-Path $evidence "verification_summary.txt")
$runtimeSummary = @(
    "collected_at=$($runtime.collected_at)"
    "dashboard_health=$($pass.dashboard_health)"
    "prediction_records=$($runtime.prediction_records)"
    "zones_with_data=$($runtime.zones_with_data)"
    "mongo_prediction_records=$($runtime.mongo_prediction_records)"
    "fleet_vehicle_count=$($runtime.fleet_vehicle_count)"
    "fleet_movement_verified=$($runtime.fleet_movement_verified)"
    "upcoming_forecast_horizons=$($runtime.upcoming_forecast_horizons -join ', ')"
    "hdfs_raw_parquet_file_count=$($runtime.hdfs_raw_parquet_file_count)"
    "hdfs_raw_trip_rows=$($runtime.hdfs_raw_trip_rows)"
    "hdfs_curated_trip_rows=$($runtime.hdfs_curated_trip_rows)"
    "source_pickup_date_range=$($runtime.source_pickup_date_min)..$($runtime.source_pickup_date_max)"
    "curated_distinct_pickup_zones=$($runtime.curated_distinct_pickup_zones)"
    "kafka_topics=$($runtime.kafka_topics -join ', ')"
    "model_evaluation=$($runtime.model_evaluation.evaluation_method)"
    "test_period=$($runtime.model_evaluation.test_start_date)..$($runtime.model_evaluation.test_end_date)"
    "training_rows=$($runtime.model_evaluation.training_rows)"
    "evaluation_rows=$($runtime.model_evaluation.evaluation_rows)"
    "rmse=$($runtime.model_evaluation.rmse)"
    "mae=$($runtime.model_evaluation.mae)"
)
$output = Join-Path $root "output\playwright"
New-Item -ItemType Directory -Force -Path $output | Out-Null
$runtimeSummary | Set-Content -Encoding utf8 (Join-Path $output "verification-summary.txt")
Copy-Item -LiteralPath (Join-Path $evidence "dispatch_hotspots.json") -Destination (Join-Path $output "dispatch-hotspots.json") -Force
$checksumPaths = @(
    (Join-Path $evidence "verification_summary.json")
    (Join-Path $evidence "runtime_metrics.json")
    (Join-Path $evidence "model_metrics.json")
    (Join-Path $evidence "data_profile.json")
    (Join-Path $evidence "forced_training.log")
    (Join-Path $evidence "hdfs_raw_parquet_files.txt")
    (Join-Path $evidence "hdfs_raw_checksums.txt")
    (Join-Path $evidence "mongo_hotspot_count.json")
    (Join-Path $output "verification-summary.txt")
    (Join-Path $output "runtime-dashboard-2026-10-03.png")
    (Join-Path $output "map-hotspots.png")
    (Join-Path $output "dispatch-hotspots.json")
)
$checksums = foreach ($path in $checksumPaths) {
    if (Test-Path -LiteralPath $path) {
        [ordered]@{ path = [System.IO.Path]::GetRelativePath($root, $path); sha256 = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash }
    }
}
Save-Json "artifact_checksums.json" @($checksums)
Write-Output "[PASS] Evidence collected in $evidence"
Write-Output "[PASS] Hotspot records: $($dashboard.summary.count)"
Write-Output "[PASS] Fleet movement: $($movement.changed)"
